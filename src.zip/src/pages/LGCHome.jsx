import { Link } from "react-router-dom";
import BasicNavbar from "../components/BasicNavbar";
function LGCHome() {
  return (
    <>
      <div>
        <h1>HOMEPAGE</h1>
        <BasicNavbar></BasicNavbar>
      </div>
    </>
  );
}

export default LGCHome;
