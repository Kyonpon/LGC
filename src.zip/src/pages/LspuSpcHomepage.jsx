import College from "../components/College";
import CollegeInfo from "../components/CollegeInfo";
import GetCourses from "../components/GetCourses";
import BasicNavbar from "../components/BasicNavbar";
import "./pages-css/college-homepage.css";

function LspuSpcHomepage() {
  const collegeN = "LSPU-SPC";
  return (
    <div className="bg-main">
      <h1 className="univ-name">Laguna State Polythechnic University - SAN PABLO</h1>
      {/* <College collegeName={collegeN}></College> */}

      <CollegeInfo></CollegeInfo>
      <GetCourses collegeName={collegeN} departmentName="coe"></GetCourses>
      <GetCourses collegeName={collegeN} departmentName="cte"></GetCourses>

      <GetCourses collegeName={collegeN} departmentName="cas"></GetCourses>
      <BasicNavbar></BasicNavbar>
    </div>
  );
}

export default LspuSpcHomepage;
