import "./css/CollegeInfo.css";

function CollegeInfo() {
  return (
    <div className="bg-info-cont pb-2 m-1">
      <h1 className="univ-name">INFO</h1>
      <section className="container-fluid d-flex">
        <div className="lag-map item1">INSERT SEAL HERE</div>
        <div className="info-cont d-flex flex-column text-light text-right ml-2 w-100 item2">
          <p className="desc-dsgn">School Name</p>
          <p className="desc-dsgn">schoolemail@edu.ph | Contact numbers </p>
          <p className="desc-dsgn">School desc or Address </p>
        </div>
      </section>
    </div>
  );
}

export default CollegeInfo;
